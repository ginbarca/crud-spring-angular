# Simple CRUD
A simple project using Spring Boot (server) + Angular 4 (client). 
# Note
Angular's project is put in `src\main\resources\templates\restClient`.
Configure Spring project and Angular by yourself because its to large to upload.
# Thanks for checking!
