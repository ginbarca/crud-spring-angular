package com.example.crud.service;

import java.util.List;

import com.example.crud.model.UserAccountDTO;

public interface UserAccountService {
	void addUser(UserAccountDTO userAccountDTO);

	void updateUser(UserAccountDTO userAccountDTO);

	void deleteUser(int id);

	UserAccountDTO getUserByID(int id);

	List<UserAccountDTO> getAllUser();
}
