package com.example.crud.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.crud.dao.UserAccountDao;
import com.example.crud.entity.UserAccount;
import com.example.crud.model.UserAccountDTO;
import com.example.crud.service.UserAccountService;

@Service
@Transactional
public class UserAccountServiceImpl implements UserAccountService {

	@Autowired
	private UserAccountDao userAccountDao;

	@Override
	public void addUser(UserAccountDTO userAccountDTO) {
		UserAccount userAccount = new UserAccount();
		userAccount.setFirstName(userAccountDTO.getFirstName());
		userAccount.setLastName(userAccountDTO.getLastName());

		userAccountDao.addUser(userAccount);
		userAccountDTO.setId(userAccount.getId());
	}

	@Override
	public void updateUser(UserAccountDTO userAccountDTO) {
		UserAccount userAccount = userAccountDao.getUserByID(userAccountDTO.getId());
		if (userAccount != null) {
			userAccount.setFirstName(userAccountDTO.getFirstName());
			userAccount.setLastName(userAccountDTO.getLastName());

			userAccountDao.updateUser(userAccount);
		}
	}

	@Override
	public void deleteUser(int id) {
		UserAccount userAccount = userAccountDao.getUserByID(id);
		if (userAccount != null) {
			userAccountDao.deleteUser(userAccount);
		}

	}

	@Override
	public UserAccountDTO getUserByID(int id) {
		UserAccount userAccount = userAccountDao.getUserByID(id);
		if (userAccount != null) {
			UserAccountDTO userAccountDTO = new UserAccountDTO();
			userAccountDTO.setId(userAccount.getId());
			userAccountDTO.setFirstName(userAccount.getFirstName());
			userAccountDTO.setLastName(userAccount.getLastName());

			return userAccountDTO;
		}
		return null;
	}

	@Override
	public List<UserAccountDTO> getAllUser() {
		List<UserAccount> userAccounts = userAccountDao.getAllUser();
		List<UserAccountDTO> userAccountDTOs = new ArrayList<UserAccountDTO>();
		userAccounts.forEach(userAccount -> {
			UserAccountDTO userAccountDTO = new UserAccountDTO();
			userAccountDTO.setId(userAccount.getId());
			userAccountDTO.setFirstName(userAccount.getFirstName());
			userAccountDTO.setLastName(userAccount.getLastName());

			userAccountDTOs.add(userAccountDTO);
		});
		return userAccountDTOs;
	}

}
