package com.example.crud.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.crud.dao.UserAccountDao;
import com.example.crud.entity.UserAccount;

@Repository
@Transactional
public class UserAccountDaoImpl implements UserAccountDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addUser(UserAccount userAccount) {
		entityManager.persist(userAccount);
	}

	@Override
	public void updateUser(UserAccount userAccount) {
		entityManager.merge(userAccount);
	}

	@Override
	public void deleteUser(UserAccount userAccount) {
		entityManager.remove(userAccount);
	}

	@Override
	public UserAccount getUserByID(int id) {
		return entityManager.find(UserAccount.class, id);
	}

	@Override
	public List<UserAccount> getAllUser() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserAccount> criteriaQuery = builder.createQuery(UserAccount.class);
		Root<UserAccount> root = criteriaQuery.from(UserAccount.class);
		TypedQuery<UserAccount> typedQuery = entityManager.createQuery(criteriaQuery.select(root));
		return typedQuery.getResultList();
	}

}
