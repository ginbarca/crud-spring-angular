package com.example.crud.dao;

import java.util.List;

import com.example.crud.entity.UserAccount;

public interface UserAccountDao {
	void addUser(UserAccount userAccount);

	void updateUser(UserAccount userAccount);

	void deleteUser(UserAccount userAccount);

	UserAccount getUserByID(int id);

	List<UserAccount> getAllUser();
}
