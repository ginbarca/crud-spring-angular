import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserServiceService } from '../services/user-service.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';

@Component({
    selector: 'app-update-user',
    templateUrl: './update-user.component.html',
    styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

    private user = new User();
    private id: number;
    constructor(private userService: UserServiceService, private route: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.route.params.subscribe(params => {
            console.log(params) //log the entire params object
            console.log(params['id']) //log the value of id
            this.id = params['id'];
        });
        this.userService.getUserByID(this.id)
            .then((res) => {
                this.user = res.json();
            })
    }

    updateUser(formUpdateUser) {
        this.userService.updateUser(formUpdateUser.value);
        this.router.navigateByUrl('/list-user');
    }
}
