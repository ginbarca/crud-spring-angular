import { Component, OnInit } from '@angular/core';

import { UserServiceService } from "../services/user-service.service";
import { User } from '../user';
import { Routes, Router } from '../../../node_modules/@angular/router';

@Component({
    selector: 'app-add-user',
    templateUrl: './add-user.component.html',
    styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

    user = new User();

    constructor(private userService: UserServiceService, private router: Router) { }

    ngOnInit() {
    }

    addUser(formAddUser) {
        this.userService.addUser(formAddUser.value);
        this.router.navigateByUrl('/list-user');
    }
}
