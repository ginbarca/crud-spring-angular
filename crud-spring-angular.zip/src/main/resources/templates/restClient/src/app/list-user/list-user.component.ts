import { Component, OnInit } from '@angular/core';
import { UserServiceService } from "../services/user-service.service";
import { User } from "../user";

@Component({
    selector: 'app-list-user',
    templateUrl: './list-user.component.html',
    styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

    private users: User[];

    constructor(private userService: UserServiceService) { }

    ngOnInit() {
        this.userService.getAllUser()
            .then((res) => {
                this.users = res.json()
            });
    }

    deleteUser(user) {
        this.userService.deleteUser(user.id);
        this.users.splice(this.users.indexOf(user), 1);
    }
}
