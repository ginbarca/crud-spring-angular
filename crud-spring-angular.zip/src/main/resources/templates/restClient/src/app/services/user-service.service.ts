import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from "@angular/http";
import { } from "rxjs/add/operator/toPromise";

@Injectable({
    providedIn: 'root'
})
export class UserServiceService {

    private baseURL = 'http://localhost:8080/api';
    private headers = new Headers({ 'Content-Type': 'application/json' });
    private options = new RequestOptions({ headers: this.headers });

    constructor(private http: Http) { }

    getAllUser() {
        return this.http.get(this.baseURL + '/users', this.options)
            .toPromise();
    }

    getUserByID(id) {
        return this.http.get(this.baseURL + '/user/' + id, this.options)
            .toPromise();
    }

    deleteUser(id) {
        this.http.delete(this.baseURL + '/user/' + id, this.options)
            .toPromise();
    }

    addUser(user) {
        this.http.post(this.baseURL + '/user', JSON.stringify(user), this.options)
            .toPromise();
    }

    updateUser(user) {
        this.http.put(this.baseURL + '/user', JSON.stringify(user), this.options)
            .toPromise();
    }
}
