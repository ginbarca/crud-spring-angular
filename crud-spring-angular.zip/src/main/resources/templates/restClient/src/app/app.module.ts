import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from "@angular/router";

import { FormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";
import { AppComponent } from './app.component';
import { ListUserComponent } from './list-user/list-user.component';

import { UserServiceService } from "./services/user-service.service";
import { AddUserComponent } from './add-user/add-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';

const routesConfig: Routes = [
    { path: 'list-user', component: ListUserComponent },
    { path: 'add-user', component: AddUserComponent },
    { path: 'update-user/:id', component: UpdateUserComponent },
    { path: '', redirectTo: '/list-user', pathMatch: 'full' }
]

@NgModule({
    declarations: [
        AppComponent,
        ListUserComponent,
        AddUserComponent,
        UpdateUserComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        RouterModule.forRoot(routesConfig)
    ],
    providers: [UserServiceService],
    bootstrap: [AppComponent]
})
export class AppModule { }
